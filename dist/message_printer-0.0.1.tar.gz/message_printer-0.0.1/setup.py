from setuptools import setup, find_packages

setup(
    name="message_printer",
    version='0.0.1',
    packages=find_packages(),
)